console.log(`O resultado é ${5+4}`);
console.log(`O resultado é ${10-4}`);
console.log(`O resultado é ${20*4}`);
console.log(`O resultado é ${20/4}`);
console.log(`O resultado é ${20%4}`);

console.log('5' + 4);
console.log(4 == 4 && 4); // os dois iguais == apresenta igualdade nos números
console.log('6' === 6); // os três iguais === ele verifica toda estrutura, não só a igualdade








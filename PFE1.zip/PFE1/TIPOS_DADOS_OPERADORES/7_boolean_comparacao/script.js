console.log(1 > 2);//f
console.log(5 < 10);//v
console.log(3 >= 3);//v
console.log(5 <= 4);//f
// console.log(5 == 4);//igualdade
// console.log('José' != 'Juca');//diferente
// console.log(3 == '3');//v
// console.log(3 === '3');//f








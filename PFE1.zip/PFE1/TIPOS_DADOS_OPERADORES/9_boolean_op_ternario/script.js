console.log(5 > 2 ? 'é sim' : 'não');
console.log(false ? 5 : 4);
console.log('Matheus' == 'Matheus' ? 'Olá, Matheus' : 'Não é o Matheus');















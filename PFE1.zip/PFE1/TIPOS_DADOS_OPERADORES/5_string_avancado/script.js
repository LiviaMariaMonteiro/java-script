console.log("Primeira linha \n Segunda linha");
console.log(`A multiplicação de 5 por 3 é igual a  ${5*3}`);
console.log(" O " + " meu " + " nome " + " é " + " Lívia ");



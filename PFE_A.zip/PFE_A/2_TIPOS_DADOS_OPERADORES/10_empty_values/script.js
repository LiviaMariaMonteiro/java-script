console.log(null); //nulo
console.log(undefined);//indefinido


















console.log(typeof "Oi, meu nome é Lívia");
console.log(typeof "eu queria compra um carro");
console.log(typeof "Teste");
console.log(typeof "A");
console.log(typeof "Infinity");
console.log(typeof Infinity);





let nome = "Juca";
let idade = 28;

if (nome != undefined && nome == "Joaquim"){
    console.log("nome está definido");

}else if(nome != undefined && nome.length > 5 && idade == 50){
    console.log("Meu nome é juca");
    
}else{
    console.log("Não é o juca");
}
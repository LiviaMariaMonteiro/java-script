let idade = prompt("Qual a sua idade?");
console.log(idade)


let nome = prompt("Qual seu nome?")
console.log(nome);
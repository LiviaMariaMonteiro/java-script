let idade = 18;
if(idade == 18){
    console.log("A idade é 18")
}

if(idade > 25){
    console.log("A idade é maior do que 25"); 
}

let nome = "Alanna";
if(nome == "Alanna" && idade > 18){
    console.log('Liberado!')
}

let passaporte = true;
if(nome == "Alanna" && idade > 30 && passaporte == true){
    console.log("Liberado 2!");
}
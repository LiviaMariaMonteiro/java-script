let idade = 16;
let nome = 'Alanna';
console.log(nome);
console.log(idade);
console.log(`Meu nome é ${nome}, e tenho ${idade} anos`)
